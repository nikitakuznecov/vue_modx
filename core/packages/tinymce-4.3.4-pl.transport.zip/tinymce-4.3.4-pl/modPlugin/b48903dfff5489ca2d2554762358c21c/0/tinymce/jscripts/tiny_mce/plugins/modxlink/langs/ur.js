tinyMCE.addI18n('ur.modxlink',{
    link_desc:"Insert/edit link"
});