tinyMCE.addI18n('ia.modxlink',{
    link_desc:"Insert/edit link"
});