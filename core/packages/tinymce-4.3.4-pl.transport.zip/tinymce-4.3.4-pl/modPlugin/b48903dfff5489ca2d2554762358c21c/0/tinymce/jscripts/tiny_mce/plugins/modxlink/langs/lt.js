tinyMCE.addI18n('lt.modxlink',{
    link_desc:"Insert/edit link"
});