tinyMCE.addI18n('hr.modxlink',{
    link_desc:"Insert/edit link"
});