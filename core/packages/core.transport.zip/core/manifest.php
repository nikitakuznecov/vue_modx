<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ed8a4f24ec6a2374502bce275ffe69d6',
      'native_key' => 'core',
      'filename' => 'modNamespace/ddbac23e96c7f92d203faf10cf0c5d6e.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'c0cc02a170c7497f2993218cf2fe3ce4',
      'native_key' => 1,
      'filename' => 'modWorkspace/76eb01616e323802d4427f43b48f8ebd.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '9a3430e390adb4c59a12207eac382b72',
      'native_key' => 1,
      'filename' => 'modTransportProvider/c619a2a022beb90043839a1b9c197758.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6a9c8c4ad245e0669942de988d4b104a',
      'native_key' => 'topnav',
      'filename' => 'modMenu/38fcea420b32310e6b42ddb4064455c9.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd46beb7f179c6039a10085c795c28053',
      'native_key' => 'usernav',
      'filename' => 'modMenu/71cd95918c11ddf3ac038b1424a2b53f.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b5e6e04588482002d8834732587421b4',
      'native_key' => 1,
      'filename' => 'modContentType/9acbaeb9a00545f636c753fd59599e3d.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b9b606430986ebf31f9390202ae57b97',
      'native_key' => 2,
      'filename' => 'modContentType/07df70a817111d878bbabb0f809a9158.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e83185ea86c407a7db3e45c1c4edf032',
      'native_key' => 3,
      'filename' => 'modContentType/809109149a887944eea70afa33ab921e.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b5a704dd7792199ae997ccfc309dd177',
      'native_key' => 4,
      'filename' => 'modContentType/c8d9ee9311c86cb7430bbed17d01dc81.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '76006a9c6cb2fd6295fb7beadeed0011',
      'native_key' => 5,
      'filename' => 'modContentType/dac072cbb9179b9a591e975dc1177751.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '07058d47541c22440f52ca585044fbd2',
      'native_key' => 6,
      'filename' => 'modContentType/800f452d4fbb71548834a16736d65d3f.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '6b79b8f6631e97f83e2fc79e47cd9844',
      'native_key' => 7,
      'filename' => 'modContentType/c80ffc7c2ac638d1248902051be1f1da.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f35179b7bc3e2163f78c852a025ae223',
      'native_key' => 8,
      'filename' => 'modContentType/d7d80500fe55c36f8cdaef69f5d719fc.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '71c52a07e6e0f1711b4f658f14b59eec',
      'native_key' => NULL,
      'filename' => 'modClassMap/3782f30705a2f9e191d7b8911f2500cd.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bcb3f4bc57de4db7d19df4f2cb9e974a',
      'native_key' => NULL,
      'filename' => 'modClassMap/4967b3db924586a0d5c5bcc48a14f2f0.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'fbf1ba69f18682b66c664acb39b02a8f',
      'native_key' => NULL,
      'filename' => 'modClassMap/c4cd7d2fafa167158df4243d8f222d94.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a619d318467e9be1e660e41587b93265',
      'native_key' => NULL,
      'filename' => 'modClassMap/ca63d6241d1755d986edb98db028e87f.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'fad90a770d1e34aba68b9e2544533a6f',
      'native_key' => NULL,
      'filename' => 'modClassMap/06aa6c0c5bc05f9a3cf9dd0dcaf03660.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'fa88338d38f823c00499a0346e613431',
      'native_key' => NULL,
      'filename' => 'modClassMap/f0cf10a67a595d121997eb54826af557.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '910b81f4ca81104be5740e1d16e77cd5',
      'native_key' => NULL,
      'filename' => 'modClassMap/2d88fcd9471df1923d14570cbfadb882.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f8f2ddd5f7d74dcd5ffa2ddfefe9aefd',
      'native_key' => NULL,
      'filename' => 'modClassMap/d6812dd558ffc511e1d26974e7f013d2.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '49a6c1d0defcb78a5b68cb88af9f5d9c',
      'native_key' => NULL,
      'filename' => 'modClassMap/bbef229675721b6ec8fe734e4e087175.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a9a76858f917cbab2410207b716faea',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/29c0c79cfd2be03451f5450867d80fe9.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65bbeb35de1577c66632fc7cc7777f44',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/d566d434e4a6f72c7178727852368223.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdb945b1a45a7b96a28383308be5996f',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/399a2a75df2ef64581f08c8f21e0bc77.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf014371ff669c68867de6e7533c7500',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/5042ecb7367ebd3dea52c589e29823de.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c0a5a657d44ef06317818757eaa3635',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/93429392fb3b1e47d6dfc0c7fcfefcaa.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49e3ca6c1156cf168373c812f6029953',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/a2fa2b971ad8628ae86afdd79895cdde.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27f529c9d114b3126f6b1998ff13e896',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/dab0ea191b9ecba327c1e1c65e3d36e5.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8df0bd657824fb24327d4dcb0be28000',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/be5470002c4177cfe3b8091b0605ca04.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5bec13b78cb87b279cc32d85b4df1ae6',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/b78a6d52fa3b1fe44f0f88c44567e0b9.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5bdf126639b86dcfdca087b99bf74b7',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/3a34ff41edbe1292d83704a5c146bf53.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e95537912aa53274bd06cf6198e4e8e4',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/7f82bbd8823a0624e45ac6affc0b5648.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99c8eefb7d90e2bf44da2c716649990a',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/a4fc1fe5d43ac0227597fc52896d1af2.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5129865c106cceb28e87deb5d8abc2f',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/3327c79b5ff86fe8cd9d5c962526d63f.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd870a83e46d50f5e49fd945f6dd51c46',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/206043fd31ec71395218dc498ece86ff.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dab7c7b136f74a2e076a3d411f0def92',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/342f8f2c52e388aa6c2dd884629df008.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e8dac6df2a671aa0d287516a79f1773',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/097fc4ad2a0d419a89cd876cd8e34457.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2970883c0e1dfb16947535962974cd0e',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/918d63b2880785a6d3b8d59c4cd2a859.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7dbcd3f58722a84ef7d05d2b1aae54a6',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/82ec6dacd65eafb61645860e2d08e198.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '344eba2e9333cc3e033b3aa78e7cd626',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/068b6fba595471704e50dbb484cbe9d8.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '859625c25b76c1ced7a906debf028ace',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/e3d5b6d47696bcd1dadb25b067fb0304.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8afc6d89bcd989480f24f5a925fdea45',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/2d9111d5d4ce26f672a7dd29ac3b7237.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfab13f6cfe979f2e31b58dc93b38ca7',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/d25a286d609d19737a482fda128ca0c4.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'daa371373f3a696445e6a55256610583',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/66ce29b08d94742b2753b4d79e49c9c5.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5edf86a77cf5413effea2dd1023106d5',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/1eddc1bf8b1af703dd084025301be096.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2e7a184684c86f270748dc138c9380c',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/21b976ef7173d9f6700b2a8d7ae85246.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '187a1d46e1bae861dfc6b5487718aedf',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/787ccdcbc6a792b3c02d08778c5c540c.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53ddb963530ea5a4035d6e62bac30386',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/7575cb6860039287424b0cba6dc99c56.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf48d6e4c01706a32ae5fb8728b970ae',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/78084215e6db7f3492e72bcf1111ec45.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dfc5f6f203d2275ff6efb83bdd6d79c0',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/b9f3e6317a32ed4e715336f807428a23.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3221cf1cd864475d502b4d3fd11fb483',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/344b153fad140cf6cd274c2ef4cc6fd9.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7355810abc716b0e0281e3f5dbc7c944',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/81bc571c6fb8ecda4f3f7a53a1f2953b.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37db7a18f0fc499377ed610166b33769',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/c3cc6e24f552fa4db02ffcf2f9b276fc.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c5a286274621e28b1b82fd3d58bc7d8',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/a0a80e196f1421c5c6b9d76848456d6c.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1672aa639fe22de565cbf85bab5f592',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/f4c01ee3f02db18f2623f8969efc1cc6.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5434806a76bd6cb12aa54c301ac220bf',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/493a81ab3d26752a6c393ed795d65b99.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '912a516300f4bae49feed3a3eb7883ae',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/0007753c9bfa70ae19923a5eb6ce05df.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f5925187c17dcf0a4a9e626a12582de',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/e9e8ff89944ac835c23770643efa7550.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ca182c7092479e4ebb704b1451d242d',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/bd7ef722fcbe7e9bdd0af7e32929b566.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbc852da5e46451e1532fdd8f3ebcce2',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/414a9a3193dedca476fa12c60e163ea2.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1ef370ac2b1f3015c298ee090d2f956',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/bf46621541a91d18d3cefe1880eeddc8.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b9b81f20659be4140d6bdec80c6119f',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/ce5a82b8e1e021ccd5b0c722e461635d.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '895c0470d7fc9bf0177f52b3a7857c3e',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/7715a70459964f994e658ab0b551d51b.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '060e3ae25a5b91d0a4dffa2d92eacbba',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/efbf150b15733f2404f25bb37fbc0265.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44f0fce2176b1e0b3e912b8d86b36dce',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/dc38a8ba0cd4e8e01c239ae4189bcfff.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0815f97964e444bd3474c0a09071d991',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/f97147ee6b742aeeaa7229c8d0ca3cce.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71b7f2028247cb3cd60c498901d48c72',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/eb72b10cf9e4fb6a7e15cbefe2e7e05e.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69f655a2be6b30d19cc40682b8b574e5',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/dac0dedb5c4b1c6b73c9e38757a87d3e.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f3a8206235cfffe47c5227bc81b0a78',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/6e7c6c76a5aaefba2d92924e81a66d4f.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '949187b7273609042ae04bf2162400e7',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/c9f131b9960ee8cccc799cbce6091292.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97603c9838295abcdc7b7ababc311572',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/6d4ad4fbf32f61c75116c45a7c097474.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80fc7a2992e4684d0b652027714b9b4b',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/209a12d0c17bc2731bc1ba987784b841.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7f0ee319233441d5e7435183c0c553f',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/317602caa92d51e3b0f14ad493ec01c6.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ca1980dd44e7efc92537bdf51e6dccc',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/e8901b0cd09fee238a4abca852f3047e.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f77ececc49e54a219490d28840ef1072',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/4b06f30a5e24d5eb156c5db8d485bc58.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82bef0ae79bbf7a824d67a30a5ef9e13',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/cea7cd10ab92a58dcffc5f176b31bc0a.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c19dcf11e8d8294b5efd1cd563ed98aa',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/ee86f1cb58d836684d719ff39333685d.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd1a938bbd927ea81aec22c6bbd87c2a',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/9f494b85229acac39250252c8154199f.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a21abf436576161e3fc07d10b0b2c276',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/c8f0121ab3292b609babc93869f3bc9e.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f65dbb75ac011916ef7ee9594cd3477c',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/d94dcbe98a3f1844c53cb94256b5e979.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f771d6b503180071cb2921e540f1c0a',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/8fa7f13c2427a4e574145b9fc22fd23f.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '520ad302fc13203a8fa19f82e34e4932',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/10dc020063ca96adb3d04d46dfd937a4.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '202b48687c673fffaccb25106e149e30',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/6eb6bd78cf0dde51be627d18200ed2fe.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92cd01d5ae32de57d9b2f30b64f18b10',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/1f45c86a01168fe0eabf1e143ef27184.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b56d126f7a7fe8ec5ffeed574532288b',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/73ca63bd9b857dc873c72f798e2b5f59.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '180731b71cb286f0a88ca9219fea477c',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/850e8937a2e2f1eed2924c26d64109fc.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e095fd93e4cc7c50c036baf5df8cd6d3',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/760b794e3595546c55557b07aa19ddb7.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf2cd818299387ca49d7cd9e0b91f07a',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/3e1852b83c2960c24fb5e909f0d3aac8.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40bed3f12d68b894453a55cccbfdfe09',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/b8b6c8c4bd61337a6658e15f8a81e422.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '04844a6092039357e167dcc76fc2c0c6',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/42ca7683e97208cd4ae414ba896d9c7f.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16cea002ac481117df36bc769dd9e678',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/ea743780e0b6da86c528cfd1b9beeeda.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '911aa9f253f72253d0ae5bb51af8a95d',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/2c00d07997540424163dc0de30b8d25d.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b14493692fb15d8ec653c8f037bb8018',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/3112c88ac89c94b29d34f1c438d66d6a.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e6bc683198b566c8ec7148ac3dc4145',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/7cc2a6134b6404a358b84404d40e4660.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '749be689c2848e0e120359efc76ba253',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/4f894f2da2fdde348727b164a8fb9ed3.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc4f2b1809238a8e3317c31394a0ab69',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/89c9de70e4532977cfbd1e2fea954dde.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3eeea75ff63ab535271de8610e8869a2',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/4cb6de12e8e8f11e5dc18bf0cf8abd5c.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd50b3bf0f8df005b09c6246c65faa8ce',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/060a057a83943643ff2c3c4998fe1331.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ba67df1d7f36907b711f8992655a5f0',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/3968f1fdb4b67ddb41611cd1d3fe0b99.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bf4ceb8637871c62f21d006ca5e1819',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/ae986e9c5d9934d6a5271e497258994b.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f055fc919c261701b07251fce07bf5b',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/e73761890905f714ad561a5830b438ae.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e95cc23272a5259bccb5b080c4bc9ac',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/600e4abe792a070cb225ddc3ad9ce475.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8919debcddcc4b92682bcccb210e9145',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/dadab027f6c15d9a29bcb43acbf8cc14.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7403f801e3fafd814564660b78933bd7',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/8d1a955e4ec14763268e71875f1942c7.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58ca55e373aca638970d161a4417edcd',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/78ae579e097ba3092e43dc529d897258.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ce2646aa41c8d8d5dfc5e10c95fdb69',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/ff02c40a3d6c1226f77d822cad41ed92.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e98043b2e07f2873766660fa9b5ff48f',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/e03c6323154f9cefdcb083612a491fbc.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7399c8a3b6ae89332e18900fcabacfb9',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/13218fc0c5120045e0c204981adce70e.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bca9c912562446a12b4446016ff955a9',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/19a326e7843befacdda471eb3c554de5.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '393ef81e2ad338b03716e6c3577ed2a9',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/0ed08ebc94c6074b8cc75292515e9495.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '353ae7d47f42d687ab318d1a655d0574',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/00635987728f0d61c4b726ba510eb041.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7da93d752b5d6ba87815222fd487b975',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/fe212f66df461e83c13c401d4f868ed6.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8511d4554cad5e8615527f43da9beb87',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/3c3de1ae8af062586b9f418ed95c7c7b.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab7cdc801e1bd13e013a18e8d19eb233',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/15c677d9abbe298410bc63898b683b45.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca028567eadcfa6cd724ce0fd33dbc68',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/61bf2bac374a596122f58c8d7c34d2c9.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aff214070949cf2aca058cf1789bb6c9',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/e4e05a4ccf4bc47f2f9c92aec5c4c0c5.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '262aec2d73926140e952ea0c3d4a6ded',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/64d1fcd5bb0c7cefa7498796657798ad.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1ce39289fc927c7f4f33ac4c8567e52',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/ce52dd76855c7de9456d6865163005bd.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c46e11e89e8d253e175f21d185462c54',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/24ee6cb60a7afc59435bddd68aed1ff7.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '627899cfb92c4d94186076d82b3d99c9',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/a19f9772949c0380dc68a7c6d95cacfb.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9600687c7011c3c40d6119edabd4506',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/2c5cbb5b1e1a8345e7aa3b128d68be2c.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b67703f38b9a058aae50395effb9884',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/b071b0d6e6c8399aae74dda4315491f2.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f380c0dfcbc19f415450a4f6a295c581',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/ef6403fa73d5a563e4a6eec4271674a8.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e89925d565ee83e35f76842aaeef5cec',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/846c6e7f27f3a876ceac3d8e41cfb93a.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32e583e9f34ab549adf4693cb121b8a3',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/f33144a08c59a38b7ea69d9a7a0cbb80.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '775eecbe05159ca8b2e84db3f841da85',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/d63ea162bdaba569be53db4ca2677362.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edc15a2e8ea56706522c0d940d90d347',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/d6a9da0f8ed33c78a36a4c49626c19b7.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1321e2e6b6ba8ddf13573f70081f44f',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/5206f654394717dc71ad926486bcc520.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36aecbf7bfb1d57c415e916dea4e9953',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/cbaf9c6478c727b987024c173a2ba1d7.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed1da8d00f969aabec09919567d21f87',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/9ca8878209d117b04d7cebcf26f08eb7.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '880b9f2a5c3c4476169ebc80789b1e04',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/4ee40ef075afc62ed1122971e5268f78.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a60976ee0c72d0e5c8ca074aac730e66',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/06a7f3b9cacf8bf05159e2fbc7aa2804.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4461aa59c75abcda98721cc41b41910f',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/d72a969eb252803d1d0ccae309e3a4ea.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c05c99c963f596f21bd27d93a269dad',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/98d87a9bc870f327e2fc6ff4f5d856df.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdac1dea8a6a1b499463d92e4d6287df',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/5dad6c0e8866d0dde6569f86957d720c.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0d94be46558f8ae332a84e854054ec3',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/aa9276fda2c585f53ff1817f175eae39.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73afceee660f7db423fe843eac7f32e1',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/0247e793fbfc9f2564838caba197ee53.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84001b36e863ebdd8197a1559527a1e9',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/46fee7e95ffec9c83af958fa5035d5e6.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '894ab4bff401ae91d864668458e4971e',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/d3da1c542fe222eadaea8336d08a801f.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87ebcf1900c0a0b63616ed2b2c9e195c',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/2b47b14473aff0f55590d6e69e23d239.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0808d7a5a09966bfd4e4ee57ca230a1',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/8a4564cfdffb5e8acd6628c372f7eb60.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab2e2418c78d0dbc579464d41603c95f',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/fd4b1484dbafc17158670ed09c6cce83.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '555516cd3597c22e8b355b483a29c61e',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/a6c5e7fe1a7f14d772aa73f4ef0cf151.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1bc65772961c6d574966a9d00ec9ac91',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/89a0341a2d24785584938179c45816f9.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe6a3f67ab58d2bc21f31ab8243665fd',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/b0d868eaeaf9522d06295691c676db79.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb81fb9ab7f985793c136c33f5219b72',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/cfb6acfe0c91a074e5f600eae1d753ea.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5bbff68be5a210856e7535a2a19109da',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/fb0b78769db2288de3050383538cbbdd.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '303560125443cf30b77af0202f1eb9ec',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/60efcf09c2a73281fa2e24fa0aaed368.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eea6a92b660ba17fba759355b2c73a04',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/10fc37d2f204760b191ada1a5f849fa5.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4bf93be8594de78e742ed01f45308ba',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/269227d530f43a5d0b78cd3bfb9f1986.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6971d7b69251ea41832691b17451246e',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/e306b55f721918e82259ce2c1eaeda19.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54eb9156556332cdb6b1be7bc92c7b74',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/9bd1cef0919835e5e192ff4ce580815b.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54a7ca64cbbc764dfd4c08b7d7000989',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/8a242db9bfd243c41d6e090d64788343.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95d979ec4223d1804e9434564ffc2c85',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/4dbabeafcd0b21fb16ce53c942e59c8e.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef94655baa423742a3223822d0f3b4a5',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/e97a114f0582b5b757fc07f895e795a3.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e41ad9d15a1521bd0282eb56da9e1b0',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/502207d9e567fde605b899081750e94f.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e22f667d24352e8798d84c0003ae977',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/514f694b4c08a10c317ecfd7771f8738.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68d0bc867cb7e0d6909821a9ff77e38c',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/fe543e756f6f142deb632abed9cb105f.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b30e9148076d6c26093ec5ed4adddd22',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/382e56333d6f284ac23ac4ae78965dc9.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9de0e9ccba48f2a2206273defd9793d6',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/cd3b7f0be7fc91355652a5ac66a85ba3.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69d624ac607253e193865268f3701b18',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/03aa409d11f9d1795bf543af1df49d37.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fdbfc99da9adedc0341f1e78cb2829d',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/75d004ff21c11ae8dbff090655cac6a6.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d36d9a0895f1b71e4415e3881dcc67b',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/6a40901994f8bd5fa4a60b813e556a75.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dfe611260a78cd51af29f463dc0f4f45',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/4c3dbd4c939cc9b358a1483e87c6d342.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5a897bf540e8c9bdf6c4afadf6a10a7',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/9636812cb26023d7d242c74dee14dbfb.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b416dcd333c240701dc049f6d158710',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/94ea500ece17d255748c1fbfca3fb45c.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01ff5af7d90fab7a1d9e6cae08dba8f4',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/589a9038e1dac7f5ec43bf11eaa2d67b.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f715fbc424c0a2f84e5274608a05c2db',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/b41da40b2ff3141fe8786b7896fdbb48.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c5de6cc5c63e7fa5e4ce32384bc04b5',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/b1cfd280db20b6d88b57580723b9f7bb.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd404f22003068c80509cffcb3055d752',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/c98a9937c285e38632d9a1293879e078.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2378fde8f700d6076e73dcb0b1469f9',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/cb33e41aa18b68b16c5ebd0251fe4d82.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccf932819cee1d503666efa7280d7dd2',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/7a8c1d4ecbc69b41ee94f562973526c6.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c54dde741ea2bbc6cbf6dedd33e316d',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/9447d94bf85d4ea7c4a20907ac22b59d.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ae301c551ef29e308fa6132ddd192da',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/590a333f175484f595165d650f2a5bce.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6c3b7366dd3db09c7f94f303f6568a4',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/6e50f30cdcdccda6600f89e3b77bd698.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '021b79fc1b33c2323e98d08725122228',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/d83371cde03101881a84b6de398e708a.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f03b4e2f394580daad33ab66558e2533',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/53ec9d302b2d054ab5bb100a5edfc29b.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a519b3941e73c7297aed24104fbb6ad9',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/b40f49e3897296bd4f80460d9a84fb3a.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '543256686a7f2bc485edff171da57070',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/107011814c704ffe3f8cccf84b7d7966.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0495fab7603e22ffc6cbd65beb1ff36',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/43758e0888a69f36c30ae3a28ee55fd9.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dae91a0ea910ddce4f5e3ebc333bb31',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/a4ad86136bc1f32d17f42aaefc4f252d.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b80d87f14bfdf3831c32cd893673ff94',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/b33b8ffe7eb854525270ff5b49b34c9a.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd09690ddf1e50ef71e519b13c77652f8',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/6639a17b547ebdd9234133b670187e9b.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd37ec1ad52caa2998b0e8ff87c904728',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/440cbe87dfd297fd4e74ee4a67ce706c.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2696240bc2328749a21d526dc231a4d7',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/c6b82bd1455b3267f3933b827a4a9ae2.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b932f57d288641db3ef48e745c4e54f',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/76ae733288476d5827e4d9417006bbf7.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60bc77610af0b8bb3d834f345164cb57',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/9702e7c99510f8d3e2f2bd3a781f77a3.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fbc863f1e04bde0295c8472f796be15',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/1f856a97660d0fb4f991c5b892f22440.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2666503ff885f2094aff064519dcc74',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/8dda79d77ff1c27107854d111864ff50.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a91dcd43576625595a35cd18905b3a3',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/fe6ce7ac5cb4a14d442f508f4297e1d5.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73bcee86feb8118aeaf2e71d3766f286',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/14ce4f6bd0c61d656b6de8b25bb09474.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '604b778f494211fb70d6b64c3c2faee5',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/567226aacbf6331594500bd2f961eaf2.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3ebb0c52e2d4bf770c6ea66e79b80ab',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/b6094ec459812a02916a2b881553acbe.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd71d7bf764a7b0de86122ebc8a119863',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/157f7ee8dff2ad1f066818fb9b6f3750.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dccb8d301aeb400142f0ccffb9f4b9a',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/b0da197f70d8517f4bf601cc67df7c7b.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '508c1e627d35d72efd6efdd7a21c38c7',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/6a6040d8ff0dc3c4c907be8fcf710b84.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c18b27d1794009ecd178f4c407651c7',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/a032c7d71fa1b5c66db322dadc060fd0.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ff6d9c00d8621efc7710a03cad1c64b',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/d22f170559010b2077dbf017846a8119.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65d6b6c6f79769013507a6b4ca58468f',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/5157257226b9818a95797698887583a2.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd6a5025ab2779599c577f6ba6e10ed3',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/c931e0396d5fbbcaf91f6bf340559393.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6cd65461c713453b7fc9118fb5a2f7f7',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/6b620b021a015589d318061ad758da81.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2cbf722e945c5cfbec8d6589c3cb455',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/4cedf8b0864d41e4b8227fde68ad5078.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbb02cd4ae5b65014b285eaa53a74ca2',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/37adb1dcfc3424677051ff4f82e1bbab.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b83edc37c7640c1e65fec1aa028e52f',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/e5de91182976b4f4b0a396b9c34c4854.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9f490bcc879de97b913397b228579c6',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/dbdf7a7aa31f489512a08f465d2f4e80.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7833593b186f2c9cb9fe4f5100f87ac2',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/4e944d8e09dacf1eb0b5f5d419e8dbcd.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1420c54faa6797bb77cd2bc2012e06e',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/4172d7a50175f834da55602d3ec28869.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '24cb49930dea5b79b6cb770bc5f503ac',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/d36fc0b7cf7825391706100d7b178153.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58d220e6ee43150cfd0be424a8f62f3f',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/bd4a8e513e2c24b4adfdc341819a6d62.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53356edf9a24e2592fe61ae77a57e873',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/adeff69904684f2ee581fd8095fa9a11.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '813508b67a813ba9d15235b7f36dcf2d',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/28e51619e5aebd3b3f96a86b6ae55499.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c78d8dbed79e0c0fdcb38668655f75d',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/34bb55072e5c4e3437de3f837c3a0f10.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '310340b61774e22d3678b7ca56633479',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/6cfd7d24233e041d69f0d714ff12e152.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80514d7ed7953bb5d6607530357e32ad',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/e01afc5287d95b605881082fbe735920.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8aeac75e55b522e08fe56cb457d7d925',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/c4ffa4008a2f8146881bb7a5175fc351.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fad2ab62d0feae57848dec6e1f4c0aab',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/033b3d3854f6fbce666f0a20bdfb1004.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31e86f1285b36eb05dedf98b06dfae05',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/a6dd0d858e901b8093b0cfe5a771ef33.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '073a291900968d0061ef46627fcaec27',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/631f5a475f22c4488f6415aca8813fb8.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c021860dfd6d70d968c14ad22c11778',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/804409231a34877d325259c157a23571.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4405432b4bcb7a75c4293d2b85c1624',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/c7975a9250e03a13498381276e3cb2cd.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60b85cf6e377133272ae23b2330985d0',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/f34fa512439ba6e2dfae454544dccecf.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed4bc632946de3caf6aa16c38ea54a66',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/1a6561e41f0b9b5d753fa85af8b53078.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0bf1721ba5083edc0b78b55549265ab',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/1936c53514292d20574201b93415a5cc.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa06df1f0b1d544ebf67d0fb802eb49a',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/a866857f6be64b0d4516777268769b66.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bcd00584954d53243861120b24dba5d',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/e8ecf12d28c28116ec13d71e9815cdcf.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f66d34c987985df41feed80fe09055f8',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/9a1da7c46052c31b066cef26c304609e.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4987caaaeb270e9b91c93b7bcfac9267',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/eae9eddd6b354df71514344355191350.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e19bd54ba4d630ece11f352fd4b24f81',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/de9886b6a4572a16cabe6c1b084e479b.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bd1ee9c72214c13699f82608eb7d95e',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/a82d8ede77357ca4cd5b0e418822f794.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6043921f96545d8e2e051bbf59cc06df',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/a801ebdc62aa5efd6398970f4b5c2086.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '134459c4a06f1614b193cb0186689500',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/1127b077eaa381ff510c64fe201fb544.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ec9827cb660cd9d887ac7cf02c741d5',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/d9e2308bca6f86acd9aa5e11557f496d.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a31021404df9122e45f4499d9ebf633',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/938cc18b879f0484f8a5dd3e07c7afe0.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07954f5f3f7a9c466c9dfeef1cc170dd',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/586ce3004944f45c3f2f0e4a18680e55.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '990816d6a7d9bbfceb5e116036c33ec4',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/4a2c09d020a3d54551466c143c0fad2b.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfa5089d1abf976e42235442545394f1',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/aaadfab8652ffac18a80481b3e1dc49b.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '646ba5bbf402e966b12fa3bcae363d0a',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/dc0ca7d0097efb8d7f57b8781e0f8d48.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26508921b3e5568554182740fa8cc469',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/0bc505039b2c1ebd68c0784b9679692a.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31452a6992d3b49619065f3265150938',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/4f5d4eb3da1bd0a4be98efd5f8bd4844.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '528299ab8bff75722c994d335c41de70',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/d2070a74d4307278bd990a205b812ee7.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b24718abc15a88167ba2cc6803f1515b',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/02e67464595a72f8cf8e95e0bc6cb54a.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd1380bd8070e41196474c546d57b83b',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/c55b6ef50628b9ac58909d3498f10c69.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7388c0389c589d73e3df9532c425edc7',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/fd7d8ff7bea4af83f18d8a821deaab75.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc2dfa2d0ce6f3cbd433afa00866307e',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/c1be6d1f4ba804b0d03d38758984a258.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bde1773dd0c26d881dcd71eb990e9f47',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/593d4c31491e182b56de0813702e5290.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41a8d9d8c98ea28a492406eb31526e89',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/19919542721e53211ec4b5b43385daa0.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2020b65c855861a29f5f6d050af3e527',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/eba0e509bce9174920c2623a79abb1cf.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6066245f66deccc71f210133a81eb0b6',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/d712187126418dc2b13028872d8c7be0.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '152e9565f4b65ed684dc48505a060d07',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/61c34b7c21d6273881fa4f3217dc8888.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e4fe870aa1413948a42b794f0444214',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/0b001b7aa3226f832c9ccd0a610d47f7.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57e6cac0bcd4ffa012ed276cc21df61a',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/a9ea73d4354c938e88584dbd6c95c97e.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7daa1d56932d048f30c27cf7b3f09e57',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/85e6ad3b64299c46f13aee2e86abfe79.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91330b789634751371ed3be0b8a8907a',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/0acfb49db56d1a8c9cb62b5ff85ded0f.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6d6ce162668c935bece56b8c4db5b78',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/ee820ae002bb68928499744ffbd51880.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c392d326b5458022b257f4e49db13d22',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/1386384ecf50b224ce4cff226b2a197b.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06dc59aab2e96811d1d24b57e89268c6',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/1abf2d19acb3d73d44eda572d2fbfee0.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5309576c3d079a3a0ddf488cb850970',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/ec5cf8dd6a031b3f9fc27caa2b42eb2e.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2753e0f8b54401733eca79a9a0e97c5c',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/55383b543c06694974fadb99ab247a10.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '751bb8e3a9ec5da059cbbc626ca56abd',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/b97771491597b51e469c1426e5fd261a.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed5f21c20556766fbe0140aa0ccdaffc',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/165ff0067d92f06fb2d4241795cab535.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e658678408cd676d53e51b9785426527',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/02bc985a44e29d9605509ddafe7153b1.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8632d49c5cc3c9384c2e5de581d343d8',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/fb7a54d09ddb01b018ed37e203358dd3.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c75c2d6a121738aaff154f21ef93188',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/eeb96033c081bacefc4d9b43a0583f5e.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2538b952fd1b5cf54bf329e45175a349',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/c45183cb1fea66f8f51e82916962bcac.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71782eb675cc4be1e89e7775e47f30ec',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/2449d0047cc4312c60bd8bfb9cd87c38.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f673217bf4d9fcb24d6c5f45c679bcd',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/d1c12904e1062d4c49e5b466cf48b17a.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b52ffac530f12ef5462fd5e041f4b6d',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/456aab82374c0b336fc3dc2a972a9f90.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45e97923426d2965a1b59c1508823792',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/3e07d624c6f8e2d31f46e5124f6436bf.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54f5636609d4340310958c567a5a4a4b',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/be9b5e252a066b1c5612be72848c7fc3.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ca104351838d3b56675ce74a7d5cd14',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/8efe531e72a30261371e3f01f3e71a34.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cfc8544a0b9978cd08c66d36aa0796a',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/b4a22419fb2b3c2700af9f250815b5b6.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c76d6a6a7041f81ee28a971934df41cd',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/427eaf34b2a076262e7628822fb6884b.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bf3469f5fc19cf9125c444ce99fded3',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/8057773e512e9b83cdddd6ab662a3900.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd73dece7c510f896b65af8f3b342cdca',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/7aee1c3de02ece976c44b5d792fef66e.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba2c295acc5017a3f3310b7b58bb8ad8',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/afb5bb678977c0af84b0c034519bb908.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c04edec8faa3e961d160aa9186355cb',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/f4b8da235bc36c48467e6dfd244ba994.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae65f54ed7ca365fc285faff048106cc',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/f580b7e2a89cfcb475951bb3280ca9a1.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c3c4e163b8b025602538deca28c8d6f',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/d3cf09f915d8039cc958c259c01be20b.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9733e7f8011cb0d90cf0299f50a1b637',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/67302af8fd4aeb7bb228c3b76d172db6.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bbe815c2d1188ca5c772c94c612175a',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/81f23610f565985e78b1a3e4cefdb7be.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce29eb607d5b7a082a7974552e0a8fb7',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/b1b336497ca0159aa257aea2f18a177b.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e0219ea12b2f5a61fde4e004ad1922a',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/856c5b0f1c3dae721069e7d3a5a35834.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec2aee31caade50414aa309568d22dae',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/b32a9d85d2e487edd3f4f2d247f463b6.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af60e3bfd12f68f34191359b5cbe8d27',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/68aa02aa2896d398ce9b86fc74f1bb59.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d760c86fc518dd705b154a25b622254',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/d477c7a49be6bbd689ac7602e0891df1.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23ac8abecd9a62476097dd7562fb4488',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/00f426e493721b997416521e11f10c1f.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3206c93720d5c2cdff359503b0f543c1',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/306b87d5a693f345bd7ce05605e0ac7a.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c14bcc95ad99d14ff833c6a1f4acf06',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/bd24ce09c939f5f5cb0d3057869ca022.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '054f5057ae9b056229a7a61879219376',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/11ee7867fe9f33309fed1792c2695694.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b511eff57ef31f38ad0e2f54cdbe7645',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/2687cd2c8b46806fc3957019882ce1f2.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5815a888c50babb0604912c8946d5025',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/a65a8372800df65ed0794ee9ee6660fb.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b694496ffc9c97397a9856376f8896f',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/d4d460c203a48fd0255c043c6fd51691.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c77243119b0e0b5a6ca8443af1108374',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/6a4ac07a53b23ee375b56f3c428ec349.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4d4fea4fbeb76c1a3526b6a4a989d1f',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/87b68373191983928681c3addef4c1e6.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '078add5b415689bb12dafa41a4e40a06',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/d496c625ab08234ddb029022867401f9.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcd876e42d99fa2bcf27aba4d06ce8ab',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/88193b1ef87963a08fdb3bb9a569abd1.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8cf66ea45e37be0b40bd16c26d2763d',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/d701864484c75e0f4ecc89d400e44983.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8648c9859b558f6eac78c0a2bdc55c4d',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/a877eb2d6da7901c59bb591b2421daa8.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2d2f1c3dcc96fcedba2088a4f638a73',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/2c5d5bbf35a3098deb46f131417c7fb6.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e4d190556c6877775331d69b22f233f',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/12141727b4c26d0a29fa1f27cae5a4c1.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ebcc48cc406da38cced346c56d24159',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/0357b47d4ccd8583f90dea369f8bafac.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e96dcdfa9fb1ca3e9c55fe5634208cd',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/7fceaa7d71dff5b59c8e2923b1111205.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a236565c22b953716113411e1faf1dc',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/16b7f4d301fe575ce3d42db0d0833a0d.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34971a790e58e4c598cb69040fe13c06',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/1ecb5a3af7d0a32353a166e5426a982f.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a329d8a9490ffb802fe07557e73bdca0',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/476de7090f7696174d08e637252cdaba.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04f9a1d3e03fbc0ada27d41261ecdf93',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/2d3dbc108c0d4b8f51af5f69e3456331.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6858ad86f451984ca9a6eef33184fa86',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/6b9ccb456cf580c893becc39f6f512e2.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '828e6ab2acfe58645a567e3add4cac68',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/bf7075ca3d3652f9d20e5e39ab320f82.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8541cbdad91d12ac769220b97e4cb32c',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/65b55527f9679785664c0081f0ba2589.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4729d85c6c7f27ee1a578364000cb369',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/9f82df81fbdf590259b85410b9673330.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f17453d9c0202fae3b41baa348a411a',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/f495538be1b66526215a857c510c12bf.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa2688673db42cdf25caf6547aa5b670',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/0b154e0436721f3893adc6cc41f9c1b1.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fb36a00509fe78fe3a45df9c56705a9',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/4de56420924e4aa0695115cb9b401ecb.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27b564a3dcb32e97890eb687afea0e8a',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/67a914c65c916cc93cd6b27a09e032e5.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f6a9614729f71a05ed396bcc59d27aa',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/c33b52ecdb75ea40b5b2db2925436973.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d315d162347c9c16c0d0937c1c23e2f',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/b98ede6a0d940d5f6dad9602219d5688.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a72824906c1881fcb9dd477eda6ba17',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/eef12e259e7fd40ddbb9feca82438fbc.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea17c3050fb663807866a66e19235db1',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/4b33cc358d400a3b2b1ebf95d1d1f774.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42392325dc12c604b9e96de2ec37aae9',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/7bbbb74ff5206aa40ebb0145c86e391c.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a16a936d34499dc10142f7c73aeaa24b',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/a0428f7c8c5a3467611e6bed96a6abcb.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '394aca57a349608049e0efa461903898',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/4de09b157e043c6b3d5bd806c85b414f.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18d9fb47b001e4216b522c7c2270cee7',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/8076b91c63e8ebc6b0df36ed87601317.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66721937eae34f65d71684f92d7dc80a',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/848ce3e10edf9f3afa9b507a76a4e2bd.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f581dcd06f5855e18c6b5937e445639',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/145995640eb3268e4dae082243aa4588.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1dcaa2d3661a617436d18b821dd1ce7',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/580ba456a6e8268b2e15b8256f238301.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62e8f7bf6423ad6741240ddeb17ca4c0',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/ad8d59aae94be1380fb6013b207ed830.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3ce7b8a37d37d994dbe04ac91471327',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/c73e6c08c79ec9b9d77f3127f95c952a.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbde8b3ad805d0fd6c3a694aac2610c8',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/b3ccc983df835fbe5a9991e8c789df2c.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba72226878379227f9fad2c22c144438',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/802aeb099007135804cf1f418a42a571.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4175174d7730875fd63a35c6359aa451',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/ff6c82e3274bc1fcbadb625cda5d985a.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a4d2f8d82dadf589d026492b6f8358d',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/5d965205f2de8c29f34d38679a00f1d4.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '238e92c4c109daa1cfcea81eb2504fbd',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/5d6d1470240aa0ed2942e772ebe7315c.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44cd9a7ea7adf27d1d8ffc2fd67a685d',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/1257352d240fd3d7027883c34f6e47f3.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f6279c6648c8f5b85fdca8f0f2bfb44',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/85c0a1228f08e270b9a5836da277c7ac.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea12625f0d71dc788dc7fd99b80a54d2',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/0d8c37da3871de45f89562d4669331e7.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10eb6a9b338c628f517ca73b0a796d0f',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/903c1e0fbef42f833a6ab756680b226a.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e8ad55be5d24da122d11e36b3c11c5b',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/ee6c253608c13d107e47658859e75cba.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c7f0ec1355a88a25f90ff44af1c63a2',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/4f9d8901f927b6179ca4f661931aae41.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8814bb3d99e701a2fbeaff66ad53292',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/d179425d144a95fc55ed7e5f3511a12d.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bd98a1e6c8835d4a4355fdeaa0abebd',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/68dafe68a9c719bd092d6f8f286cfca9.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2b12163e05b1a30231765d0a3785362',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/5116f85130114abb2aeafa793cbcc3ad.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0205d5fa4350deace9a1153f979aeefe',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/6ac4e5e7bcb5220bd9dedf53ab5c4c0d.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '237411616fdaf5c8427c83cf9fe24e8c',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/a2e92f1cfc5bc5c28ad20cc53210c1dd.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '894c23ca716e5c14c88920462d306b31',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/fa5b178ae524dbabcbf62c41e75a2345.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecb6f5b5acba09986c215ba2e0f47176',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/c0c3408e0748a649bd95cfa91d6e5d48.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c42896860ddf90f641ce9c26ee34eb4',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/61536d5ff5fd6be90bd3c4445af4cf8c.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '215e5d38340a599b9dd4b3900c55eb96',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/41a4d4e48c6125494bacd7aa29a64d33.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5247fe0edac085dc4706115feed57b49',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/d8fdf70a3ab0fd80f5b5abde93c5d0b7.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af87239574a8891f04c8d58ad5a952d3',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/adf5719e8d6356c78babd9ec1ad924ed.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82e271dfcfb271c350cbc9e1cf8ebf7c',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/a19f27d4b5ca5d1f590a272cebf905c8.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed43745e4c48903d77a9177d944710a6',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/733b6616938184dfc44d66574261dde5.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5334831fc0bedebcb93d2a2710e76e7',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/ab09821133086cbf0c202564fbe50774.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e9b67dc2b78c0d282332b312e978fc7',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/29fe09c48658d701801b5f9e23c53c8b.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27119b3d66a612eff90a1309e80f1560',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/6f24687a5e518a97037f606d8480b1dd.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d89f51ae2fb55bce56dd467fe5994cd',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/c8179019ef737eca5ce643ddba70e765.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '494bb877aae22418e673f621c95f903e',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/f7a5193d1e2186504618495aa9196e43.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b348605c5a72ef8d92164bca689d86a1',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/ba5692ddbd8b3b6222b8159a6254e9be.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47a532b837e8ba5ab1be17639a25649e',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/4613a3ab2580bac1d11113ad681fbe85.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edd8fdaf63910242be37b082e8bfc055',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/5c737c01e99440b6cbbc2a50d13e1237.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9e2151c223a4dff0144b933e9f8b94c',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/7c5a0eeb03e5af2e152a8c8537712b1c.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '371aab3171ac3c6b3ec35cedb3271919',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/d2f1f753060651f72554863b1816eab2.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '959e2361cd9df727354835477cf9b9f5',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/8208d681ed826bf6f9e7c14b3112d7d6.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5d9b3a5191e6d47103546f07ec0b7b1',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/54c611f5a2bdd9c0c41d442a0d5216e9.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4472e32337614a38b7e684545c9d5dde',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/aba96fbac936ef7f50394409de7e2d8f.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf29df6d44912bb022312c85bc27ff44',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/1c2bc260aa1eea9afced068aa16f287e.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f02b801426e697b6d7b87446ff13ed9',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/5ac42c021c4bd23898df5ed7a92b94b4.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d7e616d498af987dddf56dfc162a7d6',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/9763b0fefdf5c41e4531923aab7015d7.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c56c9db250e427bc0f0f2db13e239a26',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/781ffbd26b2f7e5b6478b8eee355d1d9.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e359bc0159809a0a598f967e0f97cae0',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/21e4e79269ce658caff100ec6b026784.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b8243ed871fb6937b9c30855caa1ce9',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/b41fbadfb6625f2fd30462bdcedeb45b.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c34f77e8c756a08975687dea42913fb4',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/1c16cce50a77e1d8db11b0aee5d0c32c.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec60b441d3e1a04202a1d962569ae4c3',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/76be213190de3e7bde8cf74f4f574972.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20d12dc8a70c9bc63fe8103e711a0470',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/06b6047d09896eecfbcfb4f7e874148d.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b15a475c0c3739a766e71748d4635117',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/cb599487ec55cd8379c57b333d70f376.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2b5c96008186632281da0dce6f0057b',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/5ec22b12eefcb9b29c15aede2f807a9d.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e7b827a03a0d327a3f895e35a1aa516',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/fd7cb37cdf4b3018c2c38bab0fd6eb92.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18a6d6c670286b7cc162836fe0d7e67e',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/6ddf25382b1a359fb4cc16b13cbf0acf.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf99dc4a01860206615c5f4056429596',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/55735cbe59349fee30e3c06676fbd2b6.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd48b21dbd1d04931ec4dedfb731e5834',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/7fe21350266a13200b214fe11a63e7c7.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec6f5153e68e642d092ce75a61bf833c',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/c57dd209d0e931c38a2a4e307fa9def5.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ce1ce7c510f6a152b340b59df9f25c9',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/29c29fc55b67d0037641de6e94d5481d.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44a33b0f7537a4ce91860d4e1b875ccd',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/13be04beeeedc5e95184ef5a6a579eb3.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2b7c52c5b159535a09d15d10548ac17',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/f3c2c028b536d8e17f0d2d9da0e0d3bf.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dce7b42d2be73031048654b01ab5a312',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/eb0d7196d3ed0f05aa025217cdeab55c.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30f4a34a8f36f95cf7756b3ffcf0ce02',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/f1631da5e3810d0ae1cc1c38f86a2695.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e93b2440fd6dbe5f628488812ada3ea1',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/7046360a7cbe60d29fdcaf201b1908fd.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fee765bfb9258cd437c8524680ace69',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/5fb8dca4dd41915c79c85fa8b6e6d059.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ba317a9c643a0b4a80d1415499c5fc4',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/10c0983b4b266f1a8e8fd161c73e10fb.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9909ec2630126c03daad925d9ad6742',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/67d63847af5fabde98a2fa78176ffd4d.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f859cf77f3ce7845643abf11ae6c9203',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/5a7ed33065fd59f63303b07e43984c8a.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07cdb9a95659fab662839df2382688e5',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/75ab61dcdcc46f29c6c262102bdec5d3.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1689cdbd72a4051e33d3956eb05b402e',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/f70452ee4367171ce07a2b9c7a29c1ee.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a249bcdc55d3a6279aa79125cfd11bb0',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/75ad0968fc6bcb0fbff3e02d3d67e5bc.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15e6212fea396f83910e0a17511189f3',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/2a25b1fb41e011d9825be352f68eb64d.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f5d87649745ac0eab41f321375e5415',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/1a5e8a5e37b2ce6cb6ef3bcabf96fbd7.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d04c98f7f8d964d6f8b6c0064eb6ba3',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/d563a2f265c0ea5f123d78615b44a897.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4d856ccae667b13cf2d163710fa63fe',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/4fa05bfc6779c71086ebf981a7f9c2f7.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f38feaae9ce48b34a50fde319acd3d91',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/8ecde3c9d9398fa18a5e2c698ab73abc.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a2856ddd2e880ca30c4166a1c6842c7',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/ac980df87e2807354d6b3a1c17422cb6.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63ad84b221b60a9a75083033afa71684',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/1d94b1af6d2858c687e71b2ef0fe43f1.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9400bf9a2eb06010652a36032e11a4a',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/7df23f9059a49e92754284f2e60611b3.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebdf6321ce28f61e0de515b65adc6b91',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/4829e493f459c4ac7039c4caf3f729da.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b1386a01c94048f81715af1c180bda3',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/b1b0b5bf41eb5dac907123706fc8d21f.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fbfc956ad3b0189a41f5b9d1d41b0d4',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/1be9b309e308a70732e96d456ab80ef1.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdc96ff07d5f99391703a1b7b259ceb4',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/da53132570c176dc1a5209026db4106f.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33d62834ccd09594a5b2853106c84ef2',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/8632e7147654b6b66a2ff1363f80996f.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c3b6ba066a89adf2664eecd2eb19ac5',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/531ad01e1c29c74f598d6ead20522b6e.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ead44eb6102c4c19f8d6e5c4a111ce2',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/4dea98c25ad65e18a32e54de93bf60cd.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6d7cbd073fc81cd2f08b4de70329f9f',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/3caf13abecab79105c64382767364e9a.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e34a38cbd1d5b1798333f47753045d88',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/6447307e79c3ad94f26745de9e4eeda3.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9418bcffcc4871719e4d2e118f7a9b7a',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/6d8cbc3f689d29e2dda84a9ac07b0ad8.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4f2a14b98bfc79906a9a3d392330c2b',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/3b7aa67d6cdb3c122ade2b2d53ce11ae.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea1c5b43c0cfa93b0234318c5515c29c',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/faaec8e6a13f849ab4d378ddbed3e7c2.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9933e491276a2f6651cb7cfa3acf8022',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/a1540ee024873327ae88b887e16afe38.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e455e88dfd80b890b5067613ec70f27c',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/bac0f449a2fa2d73ebc57f64c372fb38.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e318aa53ccfb872729d5646db5f0270',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/14cd8662682b80c4c476d377a14a6d08.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a5d3257ae0a1b63f13ce0c7723c75ab',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/a6b1353ea5d85ca2e1d6afb1f8ec8f61.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '107a760ceeaca4edff447e5b3ca276b4',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/f5cc976e526fbdbeee5d3c4577cd3b18.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62b75abfd271898687e74d962d169a60',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/7fe56c0f15478b924b53ed2740ed505c.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8526f809a1a3d788796ff62cbd7f5ed',
      'native_key' => 'upload_check_exists',
      'filename' => 'modSystemSetting/3941748419d0b2d778b8484d5eccf984.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f147a5d8f01371927eecd1b0b747922',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/942e4b90e229e965e08fcc518aa58aa4.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c737f5faa83985b724c44cdc295d45f',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/8be3ea917faf1e0f01c7456cc6253d21.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f0d4a1c71ac59b36b3154468c199dc7',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/f7a438e68cd1e1c37bfc120ccd307ac0.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a77b36e8cd4cf9b9b036f4b95f13c0e',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/daa599d65f98fdfcdf344594b771275d.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '784d6a9c53a545d8f10491fea1c74a8b',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/42e914e0860537abea61e66cb1f89f93.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b5e45658ab9f5c1e196b9675103e13f',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/a05232dfd106c21f32814930e7fdbb86.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b37d95d3c8657be7a861ce1305c279cb',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/54f5f57f0b4cfa0614ad3da10e3fc315.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc523492f90102d360b2c072a37be9af',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/c253a6b149012f1260608204d2e57c72.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e757879a9fe5f3baa77180abed48c67d',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/a74a23afc9508662e99b9ab19715ead0.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbe358f089685339a305b8a829a3d37f',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/3088af7ee7bd71e5a2d2db89582daef0.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3432e373658702f37e9663ec8f450d30',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/523fa2c88c1f0f7ec42dc395a316351a.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e557bcbdf7f1d9d0753d82c5255c3d6e',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/755a2b1fc277117b1fb97a0b211085be.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c23be4b155f2ade6caf4c4f1d657bc8',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/ba6cb976e27aeeee740963961ce6c758.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54e912b50a616fe460d5c8e930861e6c',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/cbfdae70fe7a8d238a0fdf72853ce21f.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f40b7c022998e7cd9be504134818f43a',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/4368f124a590e1ea8189fa2ad1f7ff2e.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f010a121935fd812036df79b60b8aa5',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/2bf5b5cc7541d5f81817bb819ab4ca1f.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2986de0023efcfc584b95f1ac88554cd',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/989169acecf136c056a726bf526b43f2.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fd9b0f253518739c6b5441d9416e61f',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/ee8909ced4c020e168e850afdae61926.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3930add1ef7f627b17c423fca7f1ca5d',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/2e088267ed8dd609b9b4acd543981e62.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2cff613d4e972eb6a832595c4f3bfa8',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/f1bfd4213306905256ac6b480192ef68.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a6bbad7a12578e2c9bf4bcf5218436f',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/a2eee85c00f6236fe61ff6c169c6b7dd.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d2063fbe61526d5c6e065b4adecd733',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/ce2f331a2f8a2f68e2cd516350aee8f7.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '371256560c21abc69763bfd594e2b82e',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/71d102a95b4349178316da58e14655ff.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ce266bcdf9236d50c2b45f2dd04e970',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/1c0dbb23952a544e33a6a5a7d225661a.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '798f3c247a28206b6abfc151d6d1541b',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/6172e03581d963e0ed8ec94b755b8766.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5e44806b40fdeff115122b94b91ec82',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/7de1c2a51230832ca96d0763a48f3ef7.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98216ac6d78624e22112f3e6d6b4e120',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/b93a9ed532a6082813c27dcdbdc00cba.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '374aeb9bef2b57d8a92651c015d1ba2a',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/8f0d743659a793cc4c037aba60fb4d27.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef27cc2a366b78c6af46a02a027e7d47',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/3c05fba44dfcd846b9fe3fca927381d2.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4b154418d6622b106f5fd91e02b0f3c',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/f83b73a6b1c1fbb1335baffab2b263fb.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc51cfb594911cd061b009c30682e461',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/012cd66c3f4078f3d1fdd67edf17d698.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38340f6243c669fca351216fc1156016',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/a2571cfff796a8583ba8eb98226ea5d5.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '0575057bf5803a896467db75aa380656',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/efc4bdab2612d5193e8d1e1f730a9b2e.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '4874f1bbf777b55a79cb8a428e1264bb',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/9d74220104ef8d514ee7937472f96b89.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'c2b40ddea9ad64a2d633d2109261fa9f',
      'native_key' => 1,
      'filename' => 'modUserGroup/3669142401fe2b10ccebb67b09b4d87b.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'ab884ccafd1e6abf786122c242d3ad2a',
      'native_key' => 1,
      'filename' => 'modDashboard/9b283ebb495825c733977836c77144fd.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '7e2756398548eb43dae8f80eec5492c6',
      'native_key' => 1,
      'filename' => 'modMediaSource/21625251b57831c2d3d5d191f417354c.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '7a1ff496389df5ce8b312f7c3dd08de9',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/ec7a9bcaaa587944b1d5b43e9273ebf1.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'b3b549b4b7fc7ca8f2d8e49b12bf5971',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/9c8a2033ec9c731ce58e6d6437a2b65b.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '9681b1e192a1a3a9eec5796b2244a7ca',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/651d5d971ec973a879aea513aba29a14.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '6071cee01c2a0acae0d237aa7369b99c',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/b611827d025e95be24ee03ac123d14b1.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'edcc5b30de2ea305ca1cc97b97cf7889',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/b62d0d162ae9f3b4902aee108db6015d.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '71d7d5f67e4fc0f77b1aa036582fb05c',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/2c7df20956c34d6ad4bdef2353b6273c.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '02b20aef9b03b73385ac64c98d822ab7',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/da42034e82f792fc2db8e85a432becbd.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '68562057396db5cf7761eb2bb9f6c4d7',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/0289d0e76960dd5b4ef4d54e3e4fa292.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd6157003b485f264e840b941354fdf5d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1c6bb21f0ac7402b6b4051f2759d0daa.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'de53835b3baae797d1a6a92a3a7a5ccb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/40aad44206a1d7d97613bae990b334b4.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e6498fdc577e109a588fae754cd7d409',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e961b647617d5f418a91b9b57d8441b1.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ec5b9250addb10389e76ea80ac80737c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/6c28a2571c8e768dcb9f5bcbb1f3e7e7.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '256a487aa08415d8c66444618c63fbfc',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/6191de911f0918f4c1002a73fa73fb4a.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e63bb1986f3c28d72582d6614e02b694',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/eecccf60b07ddad3dd156798f49a487f.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e5ac941ff9f6b523733a3ca9be439676',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/a6b999f5fea65c2719e36bbff5ebe00a.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '16ef9a8c803ac0769424723436428e6f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/4925b46dbce510b6b132d0bb62bc211c.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd3f8e1ac80ff7a9c4cba9efb2cddc6b3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/13998646c6213333bc356cd4aa6706bd.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '047c5d4fcd258410fb9b229248ca8b70',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/904b6f462fb759b5ebf2b6474ccf6bc2.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '00f4396e984a836c746bdcd9a0f68c4b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3ea8778c33b9f21cd0985d1c24d87b07.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '65fb5a052fc9a496691a61f802f70d83',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/864ed3c631ba899b8d5cb87dca6c6747.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5c466ce5d7d49f85b217d210695edb80',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/cbf9594b0fcb4a3bb34150c155de486a.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f32150313220235896893a3b98613d9e',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/9ce923a393c429be00e3d52def499192.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '17a885cae5942b7fe78835a584820ed1',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/d89c4cf6db104d9f2df9367f39681d2f.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e92b093c09a885c7094514d2e54f44bb',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/4405e3442796c4b0f9d611252f740254.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a4b7476fad97a41deefbb94d40c466cb',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/630a362c49124eec0bc28980b3d32d00.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '75b424ec81a03612c31a012d927b5201',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/0a346be5d2466109d39d33a4fee68205.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c454012b7af0027826b552784dbc8c79',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/b66aae918ff8a8ebc3a125f3d808b321.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1d987e1bde631ac826bb99e609e5be93',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/8ecc70d4baa00a7ddad0a6bae01f2590.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'cdc15d1641e1f6ecc07e9db6f83d4579',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/fbbf1d6514937bc9e20c152ef14ed31e.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'cf6ddf6bce6253fc4ea6f0c882b59134',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/026cdfe6a8ac15666ed53e3ef7e9099d.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '552f2f9b41ded349b12a1d533a8d4b0c',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/1a6b82ee378e109be0b1d226c3212062.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'aabed5f58bba898cb1e84850e000cfa5',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/58654f0a2bc4a85c2ee7d9b21eceb7dd.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '54d4dd1f28bfcc8c3115c75c40c5d155',
      'native_key' => 'web',
      'filename' => 'modContext/38e7b8f805af9274a9940c7eb809d527.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'a5ffdb65edea72fb7ce5749582cdba7a',
      'native_key' => 'mgr',
      'filename' => 'modContext/bd701b62f56ccd7d355aafd1a3424e98.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c397273063ed39c6f666d7d16c126748',
      'native_key' => 'c397273063ed39c6f666d7d16c126748',
      'filename' => 'xPDOFileVehicle/a1eebf71d95392a53de452bad5cd0587.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'bc9097600edf9a845d61b754d2be6dd3',
      'native_key' => 'bc9097600edf9a845d61b754d2be6dd3',
      'filename' => 'xPDOFileVehicle/56997cbe1ede219674775886f2d3e532.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b0c082e2d28fbd66415f6efb69b89bf1',
      'native_key' => 'b0c082e2d28fbd66415f6efb69b89bf1',
      'filename' => 'xPDOFileVehicle/9e9d50d4b0aa0afb4471d51d15fe5ef1.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '751d677b2e6c98796f162dc89555a258',
      'native_key' => '751d677b2e6c98796f162dc89555a258',
      'filename' => 'xPDOFileVehicle/054cb3db3b2e584b8841268184c6cc75.vehicle',
    ),
  ),
);