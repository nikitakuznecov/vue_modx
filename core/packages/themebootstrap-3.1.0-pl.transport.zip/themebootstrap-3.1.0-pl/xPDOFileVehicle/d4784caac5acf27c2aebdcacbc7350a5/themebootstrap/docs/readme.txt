--------------------
Theme.Bootstrap
--------------------
Author: Vasiliy Naumkin <bezumkin@yandex.ru>
--------------------

A basic theme for MODx Revolution based on Twitter Bootstrap (http://getbootstrap.com/).

Integrated with pdoTools. You do not need to install any additional snippets for basic functionality.